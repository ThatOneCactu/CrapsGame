package model;

//class for two dice
public class twoDice extends die {
	
	//variables for the constructor
	private int total;
	private int top2;
	
	//Constructor
	public twoDice(int top, int sides, int top2) {
		
		super(top, sides);
		
		this.top2 = top2;
		total = top + top2;
	}
	
	//Getters and setters
	public int getTop2() {
		return top2;
	}
	
	public int getTotal() {
		return total;
	}
	
	public void setTop2(int top2) {
		this.top2 = top2;
	}
	
	public void setTotal(int total) {
		this.total = total;
	}
	
	//Sets both dice to a random int from 1 to sides, and sets total to their sum
	@Override
	public void roll() {
		setTop(1 + (int)(Math.random() * getSides()));
		top2 = 1 + (int)(Math.random() * getSides());
		
		total = top2 + getTop();
	}
	
	//main method for testing
	public static void main(String[] args) {
		die d = new twoDice(1, 6, 1);
		System.out.println(d.getTop());
		for (int i = 0; i < 10; i++) {
			d.roll();
			System.out.println(i + ": " + d.getTop());
			
		}
		
	}

}
