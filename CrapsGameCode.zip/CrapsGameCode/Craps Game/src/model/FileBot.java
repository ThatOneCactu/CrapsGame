package model;

import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import javax.xml.bind.JAXB;
import java.util.ArrayList;
import java.util.List;

public class FileBot {

	private int x;
	private HighScores scores;
	
	public FileBot() {
		x = 0;
		scores = new HighScores();
		scores.getHighScores().add(new HighScore("Jon Smith", 5));
		createCPUProfile();
	}
	
	//returns the scores variable
	public List<HighScore> getScores() {
		
		return scores.getHighScores();
	}
	
	//sets the ArrayList scores
	public void setScores(HighScores scores) {
		
		this.scores = scores;
	}
	
	public List<HighScore> getHighScores5() {
		
		sortScores();
		
		List<HighScore> scores5 = new ArrayList<>();
		scores5.add(scores.getHighScores().get(0));
		
		if(scores.getHighScores().size() > 1) {
			
			scores5.add(scores.getHighScores().get(1));
			
			if(scores.getHighScores().size() > 2) {
				
				scores5.add(scores.getHighScores().get(2));
				
				if(scores.getHighScores().size() > 3) {
					
					scores5.add(scores.getHighScores().get(3));
					
					if(scores.getHighScores().size() > 4) {
						scores5.add(scores.getHighScores().get(4));
					}
				}
			}
		}
		
		return scores5;
	}
	
	//method to write game to a file under a player's name
	public void savePlayerProfile(HighScore score) {
		
		if(scores.getHighScores().size() > 1) {
			
			updateScoresList();
		}
		
		
		try(BufferedWriter output = Files.newBufferedWriter(Paths.get("Games.xml"))) {
			
			for (x = 0; x < scores.getHighScores().size(); x++) {
				
				if (score.getName().equals(scores.getHighScores().get(x).getName().trim())) {
					
					if(score.getScore() > scores.getHighScores().get(x).getScore()) {
						
						scores.getHighScores().set(x, score);
					}
					
					x = Integer.MAX_VALUE;
				}
			}	
			if (x < Integer.MAX_VALUE) {
				scores.getHighScores().add(score);
			}
			
			sortScores();
			
			JAXB.marshal(scores, output);
		}
		
		catch (IOException ioException) {
			System.err.println("Error opening file. Terminating.");
		}
		
		
	}
	
	
	//sets scores to current list on file
	public void updateScoresList() {
		try(BufferedReader input = Files.newBufferedReader(Paths.get("Games.xml"))){
					
					this.scores = JAXB.unmarshal(input, HighScores.class);
		}
				
		catch(IOException ioException) {
			
		}
	}
	
	public void createCPUProfile() {
		try(BufferedWriter output = Files.newBufferedWriter(Paths.get("Games.xml"))) {
			
			JAXB.marshal(scores, output);
		}
		
		catch (IOException ioException) {
			System.err.println("Error opening file. Terminating.");
		}
	}
	
	public void sortScores() {
		
		for (x = 0; x < scores.getHighScores().size(); x++) {
			
			if (x != 0) {
			
				HighScore score1 = scores.getHighScores().get(x - 1);
				HighScore scorex = scores.getHighScores().get(x);
				
				if (scorex.getScore() > score1.getScore()) {
					
					scores.getHighScores().set(x, score1);
					scores.getHighScores().set(x - 1, scorex);
					
					x = (0 - 1);
				}
			}
		}
	}
	
	//Main method for testing
	public static void main(String [] args) {
		
		FileBot fileBot = new FileBot();
		
		fileBot.createCPUProfile();
	}
	
}






