package model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class Games {

	@XmlElement(name="game") 
	   private List<Game> games = new ArrayList<>();

	   public List<Game> getGames() {return games;}
}
