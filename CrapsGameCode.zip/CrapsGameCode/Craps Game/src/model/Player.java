package model;

public class Player{
	
	//initialize variables
	private int turnScore;
	private int totalScore;
	private int highScore;
	private int firstRoll;
	private boolean loss;
	private int bet;
	private boolean pass;
	
	//Constructor
	public Player() {
		highScore = 0;
		turnScore = 0;
		totalScore = 10;
		firstRoll = 1;
		bet = 0;
		loss = false;
		pass = true;
	}
	
	//getter method for the money for the player
	public int getTotalScore() {
		return totalScore;
	}
	
	//getter method for the last roll the player got
	public int getTurnScore() {
		return turnScore;
	}
	
	//returns players high score
	public int getHighScore() {
		
		return highScore;
	}
	
	//sets player high score to parameter value
	public void setHighScore(int score) {
		
		highScore = score;
	}
	
	public void updateHighScore() {
		
		if(totalScore > highScore) {
			highScore = totalScore;
		}
	}
	
	//creates variables for the first dice roll for comparison's sake, get/set methods
	public int getFirstRoll() {
		return firstRoll;
	}
	
	//Sets player's first roll
	public void setFirstRoll(int firstRoll) {
		this.firstRoll = firstRoll;
	}
	
	//Sets player loss
	public void setLoss(boolean loss) {
		this.loss = loss;
	}
	
	//returns whether player has lost
	public boolean getLoss() {
		return loss;
	}
	
	//Sets player's money score
	public void setTotalScore(int score) {
		totalScore = score;
	}
	
	//Sets player's current roll
	public void setTurnScore(int score) {
		turnScore = score;
	}
	
	//Returns player bet amount
	public int getBet() {
		return bet;
	}
	
	//Sets player bet amount
	public void setBet(int bet) {
		this.bet = bet;
	}
	
	//Sets bet to 0
	public void resetBet() {
		bet = 0;
	}
	
	//Return whether player has bet pass
	public boolean getPass() {
		return pass;
	}
	
	//Sets bet to pass or no pass
	public void setPass(boolean pass) {
		this.pass = pass;
	}
	
	//Sets player bet to pass
	public void passTrue() {
		pass = true;
	}
	
	//Sets player bet to no pass
	public void passFalse() {
		pass = false;
	}
	
	//pays out bet to player's money
	public void payout() {
		totalScore += bet;
	}
	
	//removes bet from player's money
	public void loseOut() {
		totalScore -= bet;
	}
	
	//pays out another player's bet to player's money
	public void payout(int bet) {
		totalScore += bet;
	}
	
	//removes another player's bet to player's money
	public void loseOut(int bet) {
		totalScore = totalScore - bet;
	}
	
	//reset the last roll to zero
	public void resetTurnScore() {
		turnScore = 0;
	}
	
	//Resets total score to zero
	public void resetTotalScore() {
		totalScore = 10;
	}
	
	public void updateTurn(int roll) {
		turnScore += roll; //adds onto total money from last roll
	}
	
	//adds to total money from what the roll was
	public void saveScore() {
		totalScore += turnScore;
		resetTurnScore(); 
	}
	
}