package gui;

import javafx.animation.AnimationTimer;

public class Roller extends AnimationTimer{
	
	private long FRAMES_PER_SEC = 50L;
	private long INTERVAL = 1000000000L / FRAMES_PER_SEC;
	private int MAX_ROLLS = 2;
	
	private long last = 0;
	private int count = 0;
	
	@Override
	public void handle(long now) {
		if (now - last > INTERVAL) {
			
			last = now;
			count++;
			if(count > MAX_ROLLS) {
				stop();
				count = 0;
			}
		}
	}

}
